package com.fuchs.austin.cs360;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;

import java.util.ArrayList;
import java.util.List;

public class WeightDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weight.db";
    private static final int VERSION = 1;

    public WeightDatabase(Context context) {
        super(context, DATABASE_NAME, null , VERSION);
    }

    private static final class LoginTable {
        private static final String TABLE = "users";
        private static final String COL_EMAIL = "email";
        private static final String COL_PASSWORD = "password";
    }

    private static final class WeightsTable {
        private static final String TABLE = "weights";
        private static final String COL_ID = "_id";
        private static final String COL_DATE = "date";
        private static final String COL_WEIGHT = "weight";
        private static final String COL_USER = "user";
    }

    private static final class GoalWeightTable {
        private static final String TABLE = "goal";
        private static final String COL_ID = "_id";
        private static final String COL_GOAL = "weight";
        private static final String COL_USER = "user";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // create login table
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                LoginTable.COL_EMAIL + " text primary key, " +
                LoginTable.COL_PASSWORD + " text)");

        // create weights table
        db.execSQL("create table " + WeightsTable.TABLE + " (" +
                WeightsTable.COL_ID + " integer primary key autoincrement, " +
                WeightsTable.COL_DATE + ", " +
                WeightsTable.COL_WEIGHT + ", " +
                WeightsTable.COL_USER + ", " +
                "foreign key(" + WeightsTable.COL_USER + ") references " +
                LoginTable.TABLE + "(" + LoginTable.COL_EMAIL + ") on delete cascade)");

        // create goal weight table
        db.execSQL("create table " + GoalWeightTable.TABLE + " (" +
                GoalWeightTable.COL_ID + " integer primary key autoincrement, " +
                GoalWeightTable.COL_GOAL + ", " +
                GoalWeightTable.COL_USER + ", " +
                "foreign key(" + GoalWeightTable.COL_USER + ") references " +
                LoginTable.TABLE + "(" + LoginTable.COL_EMAIL + ") on delete cascade)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        db.execSQL("drop table if exists " + WeightsTable.TABLE);
        onCreate(db);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            // Enable foreign key constraints
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                db.execSQL("pragma foreign_keys = on;");
            } else {
                db.setForeignKeyConstraintsEnabled(true);
            }
        }
    }

    // add a user to the login table
    public boolean addUser(String email, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(LoginTable.COL_EMAIL, email);
        values.put(LoginTable.COL_PASSWORD, password);

        long result = db.insert(LoginTable.TABLE, null, values);

        return result != -1;
    }

    // verify email exists in login table
    public boolean verifyEmail(String email) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + LoginTable.TABLE +
                " where " + LoginTable.COL_EMAIL + " = ?", new String[] {email});

        return cursor.getCount() > 0;
    }

    // verify email and password combination matches one in the database
    public boolean verifyLogin(String email, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + LoginTable.TABLE +
                        " where " + LoginTable.COL_EMAIL + " = ? and " +
                        LoginTable.COL_PASSWORD + " = ?",
                new String[] {email, password});

        return cursor.getCount() > 0;
    }

    // get all weights associated with a user
    public List<Weight> getWeights(String user) {
        List<Weight> weights = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + WeightsTable.TABLE +
                " where " + WeightsTable.COL_USER + " = ?";
        Cursor cursor = db.rawQuery(sql, new String [] {user});

        if (cursor.moveToFirst()) {
            do {
                Weight weight = new Weight();
                weight.setId(cursor.getInt(0));
                weight.setDate(cursor.getString(1));
                weight.setWeight(cursor.getString(2));
                weight.setUser(cursor.getString(3));
                weights.add(weight);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return weights;
    }

    // add an individual weight with a date and weight
    public void addWeight(Weight weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(WeightsTable.COL_DATE, weight.getDate());
        values.put(WeightsTable.COL_WEIGHT, weight.getWeight());
        values.put(WeightsTable.COL_USER, weight.getUser());
        long weightId = db.insert(WeightsTable.TABLE, null, values);
        weight.setId(weightId);
    }

    // update an individual weight
    public void updateWeight(Weight weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(WeightsTable.COL_ID, weight.getId());
        values.put(WeightsTable.COL_DATE, weight.getDate());
        values.put(WeightsTable.COL_WEIGHT, weight.getWeight());
        values.put(WeightsTable.COL_USER, weight.getUser());
        db.update(WeightsTable.TABLE, values,
                WeightsTable.COL_ID + " = " + weight.getId(), null);
    }

    // delete a weight
    public void deleteWeight(long weightId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(WeightsTable.TABLE,
                WeightsTable.COL_ID + " = " + weightId, null);
    }

    // update the user's goal weight
    public void updateGoalWeight(GoalWeight goal) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(GoalWeightTable.COL_ID, goal.getId());
        values.put(GoalWeightTable.COL_GOAL, goal.getGoalWeight());
        values.put(GoalWeightTable.COL_USER, goal.getUser());
        db.update(GoalWeightTable.TABLE, values,
                GoalWeightTable.COL_USER + " = " + goal.getUser(), null);
    }
}

