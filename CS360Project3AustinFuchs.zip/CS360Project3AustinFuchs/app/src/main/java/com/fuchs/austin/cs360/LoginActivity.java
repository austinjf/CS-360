package com.fuchs.austin.cs360;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText emailEditText, passwordEditText;
    Button loginButton, createAccountButton;
    WeightDatabase loginDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // get views
        emailEditText = (EditText) findViewById(R.id.editTextEmailAddress);
        passwordEditText = (EditText) findViewById(R.id.editTextPassword);
        loginButton = (Button) findViewById(R.id.buttonLogin);
        createAccountButton = (Button) findViewById(R.id.buttonCreateAccount);

        // init db
        loginDB = new WeightDatabase(this);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = emailEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // check fields are not empty
                if (email.equals("") || password.equals(""))
                    Toast.makeText(LoginActivity.this, "Please enter email and password.", Toast.LENGTH_SHORT).show();
                else {
                    boolean userExists = loginDB.verifyEmail(email);

                    if (userExists) {
                        boolean loginVerified = loginDB.verifyLogin(email, password);

                        if (loginVerified) {
                            Intent intent = new Intent(getApplicationContext(), WeightsActivity.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(LoginActivity.this, "Incorrect username or password.", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(LoginActivity.this, "User does not exist. Please create an account.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = emailEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // check fields are not empty
                if (email.equals("") || password.equals(""))
                    Toast.makeText(LoginActivity.this, "Please enter email and password.", Toast.LENGTH_SHORT).show();
                else {
                    boolean userExists = loginDB.verifyEmail(email);

                    if (!userExists) {
                        boolean userAdded = loginDB.addUser(email, password);

                        if (userAdded) {
                            Intent intent = new Intent(getApplicationContext(), WeightsActivity.class);
                            startActivity(intent);
                        }
                    }
                }


            }
        });

    }
}