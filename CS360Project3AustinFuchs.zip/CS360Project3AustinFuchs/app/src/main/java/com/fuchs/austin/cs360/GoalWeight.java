package com.fuchs.austin.cs360;

public class GoalWeight {

    private long id;
    private String goalWeight;
    private String user;

    public GoalWeight(String goalWeight) {
        this.goalWeight = "150";
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getGoalWeight() {
        return goalWeight;
    }

    public void setGoalWeight(String goalWeight) {
        this.goalWeight = goalWeight;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
